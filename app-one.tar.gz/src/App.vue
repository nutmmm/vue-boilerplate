<template>
	<div id="app">
		<router-view></router-view>
	</div>
</template>

<script>
	export default {
		name: 'app'
	}
</script>

<style>
	#app, body, html{
		box-sizing: border-box;
		height: 100%;
		padding: 0px;
		margin: 0px;
	}
</style>
